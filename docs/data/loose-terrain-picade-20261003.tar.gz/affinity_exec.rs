use std::{io, os::unix::process::CommandExt, process::Command};

unsafe extern "C" {
    fn sched_setaffinity(pid: i32, size: usize, mask: *const u64) -> i32;
}

fn main() -> io::Result<()> {
    let mut args = std::env::args().skip(1);
    let core: u32 = args.next().expect("CPU core").parse().expect("integer core");
    assert!(core < 64);
    let mask = 1_u64 << core;
    // Change only this helper's affinity; exec inherits it in the benchmark.
    if unsafe { sched_setaffinity(0, size_of::<u64>(), &mask) } != 0 {
        return Err(io::Error::last_os_error());
    }
    let executable = args.next().expect("executable");
    Err(Command::new(executable).args(args).exec())
}
