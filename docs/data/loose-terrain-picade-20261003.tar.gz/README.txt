Picade shared-terrain benchmark review, local date 2026-10-03 (America/Los_Angeles)

Run python3 analyze.py from the extracted archive directory to recreate summary.json and summary.csv. Run python3 render_tables.py to recreate tables.txt. Python standard library only.

manifest.json identifies the baseline/current commits, locked Rust dependencies, build flags, exact source patches and executable SHA-256 values. jobs.json and run-picade.sh record the 66 serial matrix invocations. results/ contains runner stdout/stderr, JSON reports, execution statuses and periodic thermal telemetry. The scripts retain the original remote temporary paths; use fresh directories when repeating the commands.

run-focused.sh records the additional repeated-edit follow-up, after the complete main matrix. affinity_exec.rs changes only its own CPU affinity and execs the unchanged benchmark binary on CPU 2. results-focused/ contains all 20 alternating before/after runs. The original kiosk stays running and its game stays paused; CPU affinity does not make this an isolated-machine benchmark. Linux scaling_cur_freq is not a firmware throttling measurement.

Statistics are medians and observed min/max of the runner's own per-run statistics, not a pooled percentile or a confidence interval. Each normal matrix case has 3 runs; surface geometry includes 3 inner repeats per execution (9 observations per build/planet). The focused edit follow-up has 10 runs per build. Step, edit, collider, frame-construction and model-solver timings have different scopes and should not be combined into one FPS estimate.

The MPM comparison is a prescribed-contact lab, without terrain lifecycle or two-way actor coupling. The integrated game comparison uses 192 grains, seed 42, one-unit cells, friction 0.6, restitution zero and heavy asteroids at one-second mean intervals. Round/angular change only contact shape. Game states evolve differently between modes. Frame construction excludes rasterization and display.

release-order-diagnostic.json explains the native granular workload's changed trajectories. probe-*.jsonl, release_order_probe.rs and diagnostic-source-first.patch reproduce the diagnosis on the workstation. Restoring the old source-first publication order in an isolated worktree reproduced all recorded probe snapshots and all non-timing results of the nine-case sandbox workload. That patch weakens transaction rollback ordering and was never applied to production. Diagnostic execution times are excluded from the Pi performance comparison.

benchmark-shape-selection.patch is the exact measured patch on top of current_revision. final-runner.patch additionally hardens end-of-run conservation checks and permits legitimate zero-grain short/tiny-budget cases, outside the timed regions. No installed Pi binaries, settings or services were changed. Executables are not included in this archive; their hashes are retained in the manifest and remote-sha256.txt.
