#!/bin/sh
set -eu
cd /tmp/terrain-benchmark-review.NOqdnuuf
mkdir -p results
probe() {
    printf 'utc_seconds,temp_millic,cpu_khz,undervoltage\n'
    while :; do
        stamp=$(date +%s)
        temp=$(cat /sys/class/thermal/thermal_zone0/temp)
        freq=$(cat /sys/devices/system/cpu/cpu0/cpufreq/scaling_cur_freq)
        volts=$(cat /sys/class/hwmon/hwmon1/in0_lcrit_alarm)
        printf '%s,%s,%s,%s\n' "$stamp" "$temp" "$freq" "$volts"
        sleep 2
    done
}
probe > results/telemetry.csv &
probe_pid=$!
trap 'kill "$probe_pid" 2>/dev/null || :' EXIT HUP INT TERM
printf 'label,start,end,exit\n' > results/jobs.csv
failures=0
run_case() {
    label=$1
    shift
    start=$(date +%s)
    printf 'START %s %s\n' "$label" "$start"
    if "$@" > "results/$label.stdout" 2> "results/$label.stderr"; then
        status=0
    else
        status=$?
        failures=$((failures + 1))
    fi
    end=$(date +%s)
    printf '%s,%s,%s,%s\n' "$label" "$start" "$end" "$status" >> results/jobs.csv
    printf 'FINISH %s exit=%s seconds=%s\n' "$label" "$status" "$((end-start))"
}

run_case r1-loose-off current/loose_terrain_benchmark --mode off
run_case r1-loose-round current/loose_terrain_benchmark --mode round
run_case r1-loose-angular current/loose_terrain_benchmark --mode angular
run_case r1-soil-mpm current/soil_mpm_lab --benchmark --model mpm --build-label 2d6aa96+benchmark-config --output /tmp/terrain-benchmark-review.NOqdnuuf/results/r1-soil-mpm
run_case r1-soil-grains current/soil_mpm_lab --benchmark --model grains --build-label 2d6aa96+benchmark-config --output /tmp/terrain-benchmark-review.NOqdnuuf/results/r1-soil-grains
run_case r1-soil-frictionless current/soil_mpm_lab --benchmark --model frictionless --build-label 2d6aa96+benchmark-config --output /tmp/terrain-benchmark-review.NOqdnuuf/results/r1-soil-frictionless
run_case r1-baseline-terrain_benchmark baseline/terrain_benchmark
run_case r1-current-terrain_benchmark current/terrain_benchmark
run_case r1-baseline-fragment_benchmark baseline/fragment_benchmark
run_case r1-current-fragment_benchmark current/fragment_benchmark
run_case r1-baseline-mining_benchmark baseline/mining_benchmark
run_case r1-current-mining_benchmark current/mining_benchmark
run_case r1-baseline-impact_benchmark baseline/impact_benchmark
run_case r1-current-impact_benchmark current/impact_benchmark
run_case r1-baseline-granular_sandbox baseline/granular_sandbox --verify-replay
run_case r1-current-granular_sandbox current/granular_sandbox --verify-replay
run_case r1-baseline-spacewars_terrain_benchmark baseline/spacewars_terrain_benchmark
run_case r1-current-spacewars_terrain_benchmark current/spacewars_terrain_benchmark
run_case r1-baseline-surface_geometry_benchmark baseline/surface_geometry_benchmark --out /tmp/terrain-benchmark-review.NOqdnuuf/results/r1-baseline-surface_geometry_benchmark
run_case r1-current-surface_geometry_benchmark current/surface_geometry_benchmark --out /tmp/terrain-benchmark-review.NOqdnuuf/results/r1-current-surface_geometry_benchmark
run_case r1-baseline-terrain_collider_benchmark baseline/terrain_collider_benchmark --out /tmp/terrain-benchmark-review.NOqdnuuf/results/r1-baseline-terrain_collider_benchmark
run_case r1-current-terrain_collider_benchmark current/terrain_collider_benchmark --out /tmp/terrain-benchmark-review.NOqdnuuf/results/r1-current-terrain_collider_benchmark
run_case r2-loose-round current/loose_terrain_benchmark --mode round
run_case r2-loose-angular current/loose_terrain_benchmark --mode angular
run_case r2-loose-off current/loose_terrain_benchmark --mode off
run_case r2-soil-grains current/soil_mpm_lab --benchmark --model grains --build-label 2d6aa96+benchmark-config --output /tmp/terrain-benchmark-review.NOqdnuuf/results/r2-soil-grains
run_case r2-soil-frictionless current/soil_mpm_lab --benchmark --model frictionless --build-label 2d6aa96+benchmark-config --output /tmp/terrain-benchmark-review.NOqdnuuf/results/r2-soil-frictionless
run_case r2-soil-mpm current/soil_mpm_lab --benchmark --model mpm --build-label 2d6aa96+benchmark-config --output /tmp/terrain-benchmark-review.NOqdnuuf/results/r2-soil-mpm
run_case r2-current-terrain_benchmark current/terrain_benchmark
run_case r2-baseline-terrain_benchmark baseline/terrain_benchmark
run_case r2-current-fragment_benchmark current/fragment_benchmark
run_case r2-baseline-fragment_benchmark baseline/fragment_benchmark
run_case r2-current-mining_benchmark current/mining_benchmark
run_case r2-baseline-mining_benchmark baseline/mining_benchmark
run_case r2-current-impact_benchmark current/impact_benchmark
run_case r2-baseline-impact_benchmark baseline/impact_benchmark
run_case r2-current-granular_sandbox current/granular_sandbox --verify-replay
run_case r2-baseline-granular_sandbox baseline/granular_sandbox --verify-replay
run_case r2-current-spacewars_terrain_benchmark current/spacewars_terrain_benchmark
run_case r2-baseline-spacewars_terrain_benchmark baseline/spacewars_terrain_benchmark
run_case r2-current-surface_geometry_benchmark current/surface_geometry_benchmark --out /tmp/terrain-benchmark-review.NOqdnuuf/results/r2-current-surface_geometry_benchmark
run_case r2-baseline-surface_geometry_benchmark baseline/surface_geometry_benchmark --out /tmp/terrain-benchmark-review.NOqdnuuf/results/r2-baseline-surface_geometry_benchmark
run_case r2-current-terrain_collider_benchmark current/terrain_collider_benchmark --out /tmp/terrain-benchmark-review.NOqdnuuf/results/r2-current-terrain_collider_benchmark
run_case r2-baseline-terrain_collider_benchmark baseline/terrain_collider_benchmark --out /tmp/terrain-benchmark-review.NOqdnuuf/results/r2-baseline-terrain_collider_benchmark
run_case r3-loose-angular current/loose_terrain_benchmark --mode angular
run_case r3-loose-off current/loose_terrain_benchmark --mode off
run_case r3-loose-round current/loose_terrain_benchmark --mode round
run_case r3-soil-frictionless current/soil_mpm_lab --benchmark --model frictionless --build-label 2d6aa96+benchmark-config --output /tmp/terrain-benchmark-review.NOqdnuuf/results/r3-soil-frictionless
run_case r3-soil-mpm current/soil_mpm_lab --benchmark --model mpm --build-label 2d6aa96+benchmark-config --output /tmp/terrain-benchmark-review.NOqdnuuf/results/r3-soil-mpm
run_case r3-soil-grains current/soil_mpm_lab --benchmark --model grains --build-label 2d6aa96+benchmark-config --output /tmp/terrain-benchmark-review.NOqdnuuf/results/r3-soil-grains
run_case r3-baseline-terrain_benchmark baseline/terrain_benchmark
run_case r3-current-terrain_benchmark current/terrain_benchmark
run_case r3-baseline-fragment_benchmark baseline/fragment_benchmark
run_case r3-current-fragment_benchmark current/fragment_benchmark
run_case r3-baseline-mining_benchmark baseline/mining_benchmark
run_case r3-current-mining_benchmark current/mining_benchmark
run_case r3-baseline-impact_benchmark baseline/impact_benchmark
run_case r3-current-impact_benchmark current/impact_benchmark
run_case r3-baseline-granular_sandbox baseline/granular_sandbox --verify-replay
run_case r3-current-granular_sandbox current/granular_sandbox --verify-replay
run_case r3-baseline-spacewars_terrain_benchmark baseline/spacewars_terrain_benchmark
run_case r3-current-spacewars_terrain_benchmark current/spacewars_terrain_benchmark
run_case r3-baseline-surface_geometry_benchmark baseline/surface_geometry_benchmark --out /tmp/terrain-benchmark-review.NOqdnuuf/results/r3-baseline-surface_geometry_benchmark
run_case r3-current-surface_geometry_benchmark current/surface_geometry_benchmark --out /tmp/terrain-benchmark-review.NOqdnuuf/results/r3-current-surface_geometry_benchmark
run_case r3-baseline-terrain_collider_benchmark baseline/terrain_collider_benchmark --out /tmp/terrain-benchmark-review.NOqdnuuf/results/r3-baseline-terrain_collider_benchmark
run_case r3-current-terrain_collider_benchmark current/terrain_collider_benchmark --out /tmp/terrain-benchmark-review.NOqdnuuf/results/r3-current-terrain_collider_benchmark
printf "COMPLETE failures=%s\n" "$failures"
test "$failures" = 0
