import json
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parent
report = json.loads((ROOT / 'summary.json').read_text())
assert report['jobs_completed'] == report['jobs_planned'] == 66
assert report['focused_jobs_completed'] == report['focused_jobs_planned'] == 20
assert not report['failures']
for row in report['summaries']:
    expected = (10 if row['suite'] == 'terrain_benchmark_fixed_cpu' else
                9 if row['suite'] == 'surface_geometry_benchmark' else 3)
    assert row['runs'] == expected, (row['suite'], row['case'], row['runs'])
    assert row['evidence_repeats_exactly'], (row['suite'], row['case'])
for pair in report['paired']:
    assert pair['evidence_matches'] or pair['suite'] == 'granular_sandbox', pair

values = json.loads((ROOT / 'findings.json').read_text())
values.update(temperature='–'.join(f'{t:.1f}' for t in report['temperature_c']),
              frequencies=', '.join(f'{f / 1_000_000:g}' for f in report['cpu_khz']),
              undervoltage=str(report['undervoltage_samples']))
tables = (ROOT / 'tables.txt').read_text()
for match in re.finditer(r'([A-Z_]+_TABLE)\n\n(.*?)(?=\n[A-Z_]+_TABLE\n|\Z)', tables, re.S):
    values[match[1]] = match[2].strip()
template = (ROOT / 'review-narrative.txt').read_text()
section = re.sub(r'\{([a-zA-Z_]+)\}', lambda m: values[m[1]], template)
assert not re.search(r'\{[a-zA-Z_]+\}', section)
(ROOT / 'report-section.txt').write_text(section)
