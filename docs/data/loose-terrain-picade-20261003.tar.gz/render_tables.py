import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
report = json.loads((ROOT / 'summary.json').read_text())
index = {(r['suite'], r['build'], r['case']): r for r in report['summaries']}
out = []

def table(title, headers, rows):
    out.extend([title, '', '| ' + ' | '.join(headers) + ' |',
                '| ' + ' | '.join(['---'] * len(headers)) + ' |'])
    out.extend('| ' + ' | '.join(map(str, row)) + ' |' for row in rows)
    out.append('')

def value(row, metric, key='median'):
    return row['timings'][metric][key]

def spread(row, metric):
    t = row['timings'][metric]
    return f"{t['median']:.2f} ({t['min']:.2f}–{t['max']:.2f})"

rows = []
for scene in ['combat', 'match']:
    for mode in ['off', 'round', 'angular']:
        r = index['loose_terrain_benchmark', 'current', f'{scene} / {mode}']
        rows.append([scene, mode, f"{value(r, 'step_mean_ms'):.2f}", spread(r, 'step_p95_ms'),
                     f"{value(r, 'step_p99_ms'):.2f}", f"{value(r, 'step_max_ms', 'max'):.2f}",
                     f"{value(r, 'frame_p95_ms'):.2f}", r['evidence']['grains'], r['evidence']['blocked']])
table('GAME_TABLE', ['Scene', 'Dirt', 'Mean', 'p95 (run range)', 'p99', 'Worst step',
                     'Frame p95', 'Final grains', 'Rejected impacts'], rows)

rows = []
for fixture in ['flat', 'moving-planet']:
    for experiment in ['pour', 'bank', 'blasts']:
        m = index['soil_mpm_lab', 'current', f'{fixture} / {experiment} / mpm']
        g = index['soil_mpm_lab', 'current', f'{fixture} / {experiment} / grains']
        rows.append([f'{fixture} / {experiment}', m['evidence']['final']['particles'],
                     f"{value(m, 'mean_ms'):.2f}", spread(m, 'p95_ms'),
                     f"{value(g, 'mean_ms'):.2f}", spread(g, 'p95_ms'),
                     f"{value(g, 'mean_ms') / value(m, 'mean_ms'):.2f}×"])
table('SOIL_TABLE', ['Fixture / experiment', 'Samples', 'MPM mean', 'MPM p95 (range)',
                    'Grains mean', 'Grains p95 (range)', 'Grains / MPM mean'], rows)

rows = []
names = {'terrain_benchmark': 'Edits', 'fragment_benchmark': 'Fragments',
         'mining_benchmark': 'Mining', 'impact_benchmark': 'Impacts',
         'spacewars_terrain_benchmark': 'Spacewars', 'surface_geometry_benchmark': 'Geometry',
         'terrain_collider_benchmark': 'Colliders'}
for suite, label in names.items():
    metric = {'surface_geometry_benchmark': 'refresh.p95_ms',
              'terrain_collider_benchmark': 'steps.p95_ms'}.get(suite, 'step_p95_ms')
    for p in report['paired']:
        if p['suite'] != suite:
            continue
        a = index[suite, 'baseline', p['case']]
        b = index[suite, 'current', p['case']]
        rows.append([label, p['case'], f'{value(a, metric):.3f}', f'{value(b, metric):.3f}',
                     f"{p['changes_percent'][metric]:+.1f}%"])
table('EXISTING_TABLE', ['Benchmark', 'Case', 'Before p95', 'After p95', 'Change'], rows)

rows = []
for p in report['paired']:
    if p['suite'] != 'granular_sandbox':
        continue
    a = index[p['suite'], 'baseline', p['case']]
    b = index[p['suite'], 'current', p['case']]
    rows.append([p['case'], f"{value(a, 'native_update.p95_ms'):.2f}",
                 f"{value(b, 'native_update.p95_ms'):.2f}", a['evidence']['peak_loose_bodies'],
                 b['evidence']['peak_loose_bodies']])
table('SANDBOX_TABLE', ['Fixture / preset', 'Before p95', 'After p95',
                        'Before peak bodies', 'After peak bodies'], rows)

rows = []
for p in report['paired']:
    if p['suite'] != 'terrain_benchmark_fixed_cpu':
        continue
    a = index[p['suite'], 'baseline', p['case']]
    b = index[p['suite'], 'current', p['case']]
    rows.append([p['case'], spread(a, 'step_p95_ms'), spread(b, 'step_p95_ms'),
                 f"{p['changes_percent']['step_p95_ms']:+.1f}%"])
table('FOCUSED_TABLE', ['Cell size / edit', 'Before p95 (range)', 'After p95 (range)', 'Change'], rows)
(ROOT / 'tables.txt').write_text('\n'.join(out) + '\n')
