import csv
import json
import statistics
from collections import defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parent
RESULTS = ROOT / 'results'
jobs = json.loads((ROOT / 'jobs.json').read_text())
finished = {r['label']: r for r in csv.DictReader((RESULTS / 'jobs.csv').open())}
records = []
failures = []

CSV_KEYS = {
    'terrain_benchmark': ['cell_size','workload'],
    'fragment_benchmark': ['case','radius'],
    'mining_benchmark': ['tool','radius'],
    'impact_benchmark': ['case','radius','impacts_enabled'],
    'spacewars_terrain_benchmark': ['case'],
    'loose_terrain_benchmark': ['scene','mode'],
}

def add(suite, build, repeat, case, timings, evidence):
    records.append(dict(suite=suite, build=build, repeat=repeat, case=case,
                        timings=timings, evidence=evidence))

for job in jobs:
    label = job['label']
    if label not in finished:
        continue
    if int(finished[label]['exit']) != 0:
        failures.append({'job': label, 'exit': finished[label]['exit'],
                         'stderr': (RESULTS / (label+'.stderr')).read_text()[-3000:]})
        continue
    build, suite = job['command'][0].split('/')
    repeat = int(label[1])
    if suite in CSV_KEYS:
        for row in csv.DictReader((RESULTS / (label+'.stdout')).open()):
            case = ' / '.join(row[k] for k in CSV_KEYS[suite])
            timings = {k: float(v) for k,v in row.items() if k.endswith('_ms')}
            evidence = {k: v for k,v in row.items() if k not in timings}
            add(suite, build, repeat, case, timings, evidence)
    elif suite == 'granular_sandbox':
        report = json.loads((RESULTS / (label+'.stdout')).read_text())
        assert len(report['cases']) == 9, label
        for row in report['cases']:
            assert row['ticks'] == 600 and row['same_build_replay_verified'], label
            assert row['native_update']['samples'] == 596, label
            assert row['event_update']['samples'] == 4, label
            assert row['frame_construction']['samples'] == 600, label
            timing_keys = ['native_update', 'event_update', 'frame_construction']
            timings = {f'{part}.{key}': value for part in timing_keys
                       for key,value in row[part].items() if key.endswith('_ms')}
            add(suite, build, repeat, row['fixture']+' / '+row['preset'], timings,
                {k:v for k,v in row.items() if k not in timing_keys})
    elif suite == 'soil_mpm_lab':
        report = json.loads((ROOT / job['report']).read_text())
        assert len(report['cases']) == 6 and report['benchmark_only'], label
        for row in report['cases']:
            assert len(row['step_ms']['all']) == 600, label
            add(suite, build, repeat, ' / '.join(row[k] for k in ['fixture','experiment','model']),
                {k+'_ms': v for k,v in row['step_ms'].items() if k != 'all'},
                {k:row[k] for k in ['seed','initial','final','events','samples','solver']})
    elif suite == 'surface_geometry_benchmark':
        report = json.loads((ROOT / job['report']).read_text())
        for row in report['reports']:
            timings = {'initial_build_ms':row['initial_build_ms']}
            timings.update({f'{part}.{k}':v for part in ['edits','refresh']
                            for k,v in row[part].items() if k.endswith('_ms')})
            evidence = {k:v for k,v in row.items() if k not in ['initial_build_ms','edits','refresh','repeat']}
            add(suite, build, repeat, str(row['planet'])+' / '+row['surface'], timings, evidence)
    elif suite == 'terrain_collider_benchmark':
        report = json.loads((ROOT / job['report']).read_text())
        assert report['equal_work'] and len(report['cases']) == 4, label
        for row in report['cases']:
            assert row['steps']['count'] == 3600, label
            assert row['broad_phase']['count'] == 3600, label
            assert row['synchronize']['count'] == 39, label
            parts=['steps','broad_phase','synchronize']
            timings={f'{part}.{k}':v for part in parts for k,v in row[part].items() if k.endswith('_ms')}
            add(suite, build, repeat, row['surface']+' / '+row['layout'], timings,
                {k:v for k,v in row.items() if k not in parts})

focused = RESULTS.parent / 'results-focused'
focused_finished = []
if (focused / 'jobs.csv').exists():
    focused_finished = list(csv.DictReader((focused / 'jobs.csv').open()))
    for job in focused_finished:
        label = job['label']
        if int(job['exit']) != 0:
            failures.append({'job': label, 'exit': job['exit'],
                             'stderr': (focused / (label+'.stderr')).read_text()[-3000:]})
            continue
        repetition, build, _ = label.split('-', 2)
        for row in csv.DictReader((focused / (label+'.stdout')).open()):
            timings = {k:float(v) for k,v in row.items() if k.endswith('_ms')}
            add('terrain_benchmark_fixed_cpu', build, int(repetition[1:]),
                ' / '.join(row[k] for k in CSV_KEYS['terrain_benchmark']), timings,
                {k:v for k,v in row.items() if k not in timings})

by_case=defaultdict(list)
for record in records:
    by_case[(record['suite'],record['build'],record['case'])].append(record)
summaries=[]
for (suite,build,case), rows in by_case.items():
    timings={}
    for key in rows[0]['timings']:
        vals=[r['timings'][key] for r in rows]
        timings[key]={'median':statistics.median(vals),'min':min(vals),'max':max(vals)}
    signatures={json.dumps(r['evidence'],sort_keys=True) for r in rows}
    summaries.append(dict(suite=suite,build=build,case=case,runs=len(rows),
                          repetitions=sorted({r['repeat'] for r in rows}),
                          evidence_repeats_exactly=len(signatures)==1,
                          timings=timings,evidence=rows[0]['evidence']))
summary_index={(r['suite'],r['build'],r['case']):r for r in summaries}
paired=[]
for current in summaries:
    if current['build']!='current': continue
    baseline=summary_index.get((current['suite'],'baseline',current['case']))
    if not baseline: continue
    paired.append(dict(suite=current['suite'],case=current['case'],
                       evidence_matches=baseline['evidence']==current['evidence'],
                       changes_percent={key:(vals['median']/baseline['timings'][key]['median']-1)*100
                         for key,vals in current['timings'].items()
                         if baseline['timings'][key]['median']>0}))
telemetry=list(csv.DictReader((RESULTS/'telemetry.csv').open()))
temps=[int(r['temp_millic'])/1000 for r in telemetry]
frequencies=sorted({int(r['cpu_khz']) for r in telemetry})
report=dict(jobs_completed=len(finished),jobs_planned=len(jobs),failures=failures,
            focused_jobs_completed=len(focused_finished),focused_jobs_planned=20,
            temperature_c=[min(temps),max(temps)],cpu_khz=frequencies,
            undervoltage_samples=sum(int(r['undervoltage'])!=0 for r in telemetry),
            summaries=summaries,paired=paired)
(ROOT/'summary.json').write_text(json.dumps(report,indent=2))
with (ROOT/'summary.csv').open('w') as file:
    w=csv.writer(file);w.writerow(['suite','build','case','runs','metric','median_ms','min_ms','max_ms'])
    for row in summaries:
        for metric,vals in row['timings'].items():
            w.writerow([row['suite'],row['build'],row['case'],row['runs'],metric,*[vals[k] for k in ['median','min','max']]])
print(f"Completed {len(finished)}/{len(jobs)}, {len(failures)} failed; temperature {min(temps):.1f}–{max(temps):.1f} C; CPU {frequencies} kHz")
for suite in ['loose_terrain_benchmark','soil_mpm_lab']:
    for row in summaries:
        if row['suite']!=suite:continue
        t=row['timings'];mean=t.get('step_mean_ms',t.get('mean_ms'));p95=t.get('step_p95_ms',t.get('p95_ms'))
        print(f"{suite}: {row['case']}: mean {mean['median']:.3f}, p95 {p95['median']:.3f} ms, {row['runs']} runs")
for row in paired:
    if not row['evidence_matches']: print('NON-TIMING DIFFERENCE:',row['suite'],row['case'])
for row in summaries:
    if not row['evidence_repeats_exactly']: print('REPEAT DIFFERENCE:',row['suite'],row['build'],row['case'])
