#!/bin/sh
set -eu
cd /tmp/terrain-benchmark-review.NOqdnuuf
# Wait for the existing serial matrix to finish; never overlap benchmark jobs.
while kill -0 2741 2>/dev/null; do sleep 5; done
test "$(wc -l < results/jobs.csv)" -eq 67
mkdir results-focused
printf 'label,start,end,exit,temp_start_millic,temp_end_millic\n' > results-focused/jobs.csv
for repeat in $(seq 1 10); do
    if test "$((repeat % 2))" -eq 1; then builds='baseline current'; else builds='current baseline'; fi
    for build in $builds; do
        label="f$repeat-$build-terrain_benchmark"
        start=$(date +%s)
        before=$(cat /sys/class/thermal/thermal_zone0/temp)
        printf 'START %s\n' "$label"
        if ./affinity-exec 2 "$build/terrain_benchmark" > "results-focused/$label.stdout" 2> "results-focused/$label.stderr"; then code=0; else code=$?; fi
        end=$(date +%s)
        after=$(cat /sys/class/thermal/thermal_zone0/temp)
        printf '%s,%s,%s,%s,%s,%s\n' "$label" "$start" "$end" "$code" "$before" "$after" >> results-focused/jobs.csv
        printf 'FINISH %s exit=%s\n' "$label" "$code"
        test "$code" -eq 0
    done
done
printf 'FOCUSED COMPLETE\n'
