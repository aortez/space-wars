use engine_rapier::terrain::GrainShape;
use scenario_terrain_lab::blast_lab::{Blast, BlastLab, BlastLabConfig, BlastMode, Fixture};
use serde_json::json;

fn record(lab: &BlastLab, stage: &str) {
    lab.audit().unwrap();
    let grains: Vec<_> = lab.grains().map(|(grain, motion)| json!({
        "id": grain.id().value(),
        "material": grain.cell().material.0,
        "durability": grain.cell().durability,
        "motion_bits": ([motion.position.x, motion.position.y, motion.angle,
            motion.linear_velocity.x, motion.linear_velocity.y, motion.angular_velocity]
            .map(f32::to_bits)),
    })).collect();
    println!("{}", json!({"fixture": lab.config().fixture.name(), "stage": stage,
        "hash": format!("{:016x}", lab.content_motion_hash()), "grains": grains}));
}

fn main() {
    for fixture in [Fixture::Flat, Fixture::Slope, Fixture::MovingPlanet] {
        let mut lab = BlastLab::new(BlastLabConfig {
            fixture, mode: BlastMode::Grains, seed: 42, cell_size: 0.5,
            max_loose_bodies: 192, friction: 0.6, grain_shape: GrainShape::Round,
            ..Default::default()
        }).unwrap();
        record(&lab, "initial");
        let result = lab.blast(Blast {
            center: lab.surface_point(0.0, 0.75), radius: 3.0, speed: 26.0,
        }).unwrap();
        assert!(result.admitted);
        record(&lab, "after-release");
        for tick in 1..=60 {
            lab.step();
            record(&lab, &format!("tick-{tick}"));
        }
    }
}
