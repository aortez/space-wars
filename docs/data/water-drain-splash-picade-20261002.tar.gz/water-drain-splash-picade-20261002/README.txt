Clock drain splash paired profile, sw-picade.local, 2026-10-02.

before = commit e84a08202c2e8d9a36aacd91a1a0b8b25c14f3d5 plus splashes-off.patch.
after = the same commit, varied Lively enabled; manually accepted installed build.

No binaries or private saved settings are included in the retained archive.
The splash-off patch is diagnostic only and is not part of the shipped change.
Both release binaries use the pinned Yocto configuration in picade-runtime.yml.
Run kas from the repository's yocto directory, using kas-spacewars.yml plus
picade-runtime.yml and the same build directory/toolchain for both variants.
Do not replace these pins with current layer branch tips: the device runtime
uses Poky 5.0.18, and newer branch tips have a different compatibility ID.

The collector uses the repository's existing benchmark-clock.sh.
Place compiled executables at before/engine-client and after/engine-client,
pause the existing kiosk, then run bash run-paired.sh on the Pi.
It requires the kiosk to run as the caller and have no systemd watchdog.
SIGSTOP prevents competing rendering; an EXIT trap always sends SIGCONT.
Resume the pause menu afterward. No saved configuration is changed.

Reports are CPU frame-work measurements, not displayed FPS. Each process
resets the scenario after five warm-up seconds. Three paired runs per case
and scale alternate off/on, on/off, off/on. No other device workloads should
run during collection. Environment readings are endpoints, not continuous
throttling/frequency traces. The splash-off build retains the new optional
engine machinery; this isolates enabling the live Clock preset.

Validate and regenerate results with Python 3.10+:
  sha256sum -c SHA256SUMS
  python3 analyze.py
  python3 tables.py

Both scripts use only the standard library. Paired delta ranges contain the
three observed differences; they are not confidence intervals. Worst row
p95 is the largest one-second row p95, not an aggregate whole-run percentile.

The enabled build predates its commit and embeds a98559a48d10-dirty in the
Info screen. The disabled control embeds e84a08202c2e-dirty. Both use the
committed source identified above, with only the retained splash-off patch.
Restoring enabled sources and explicitly matching the original Info label
reproduced both deployed binary hashes exactly. The optional verification
bbappend and KAS overlay are retained; adjust its absolute BBFILES path for
another checkout. It is not needed for ordinary on/off benchmark builds.
