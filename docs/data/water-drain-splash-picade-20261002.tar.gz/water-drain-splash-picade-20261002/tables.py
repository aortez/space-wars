#!/usr/bin/env python3
"""Render compact tables from the validated run summary."""
import json
import statistics
from pathlib import Path

root = Path(__file__).resolve().parent
data = json.loads((root / 'analysis.json').read_text())
labels = {'idle': 'Idle', 'rain': 'Heavy Rain', 'meltdown': 'Meltdown'}
lines = ['| Fixture | Scale | Off (ms) | Lively (ms) | Paired change | Range of paired changes |',
         '| --- | ---: | ---: | ---: | ---: | ---: |']
for row in data['summary']:
    m = row['metrics']['avg_total_ms']
    lo, hi = m['paired_delta_range']
    lines.append(f"| {labels[row['case']]} | {row['scale']}× | {m['before_median']:.3f} | {m['after_median']:.3f} | {m['paired_delta_median']:+.3f} ms ({m['percent_of_baseline']:+.1f}%) | {lo:+.3f} to {hi:+.3f} ms |")
lines += ['', '| Fixture | Scale | Simulation off → Lively | Scene construction off → Lively | Raster preparation off → Lively |',
          '| --- | ---: | ---: | ---: | ---: |']
for row in data['summary']:
    if row['case'] == 'idle':
        continue
    cells = [labels[row['case']], f"{row['scale']}×"]
    for key in ['avg_step_ms', 'avg_render_ms', 'avg_present_ms']:
        m = row['metrics'][key]
        cells.append(f"{m['before_median']:.3f} → {m['after_median']:.3f} ms")
    lines.append('| ' + ' | '.join(cells) + ' |')
lines += ['', '| Rain phase | Scale | Simulation off → Lively | Scene construction off → Lively | Total paired change |',
          '| --- | ---: | ---: | ---: | ---: |']
for row in data['summary']:
    if row['case'] != 'rain':
        continue
    for phase, label in [('shower_seconds_1_20', 'Seconds 1–20'), ('drain_seconds_21_40', 'Seconds 21–40')]:
        stages = row['phases'][phase]
        cells = [label, f"{row['scale']}×"]
        for key in ['avg_step_ms', 'avg_render_ms']:
            m = stages[key]
            cells.append(f"{m['before_median']:.3f} → {m['after_median']:.3f} ms")
        cells.append(f"{stages['avg_total_ms']['paired_delta_median']:+.3f} ms")
        lines.append('| ' + ' | '.join(cells) + ' |')
(root / 'tables.md').write_text('\n'.join(lines) + '\n')
print('\n'.join(lines))
for case in labels:
    group = [run for run in data['runs'] if run['case'] == case]
    for key in ['max_scene_items', 'max_bodies', 'max_colliders', 'event_frames']:
        print(case, key, {v: sorted({run[key] for run in group if run['variant'] == v}) for v in ['before', 'after']})
for case in ['rain', 'meltdown']:
    for scale in [1, 2]:
        group = [run for run in data['runs'] if (run['case'], run['scale']) == (case, scale)]
        print('worst one-second-row p95', case, scale, {v: [min(run['worst_row_p95_ms'] for run in group if run['variant'] == v), max(run['worst_row_p95_ms'] for run in group if run['variant'] == v)] for v in ['before', 'after']})
