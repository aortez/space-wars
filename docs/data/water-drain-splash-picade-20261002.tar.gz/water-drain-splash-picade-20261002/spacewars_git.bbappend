do_compile:prepend() {
    export SPACEWARS_BUILD_REVISION="a98559a48d10-dirty"
}
