#!/usr/bin/env python3
"""Summarize complete fixed-workload runs, retaining paired differences."""
import argparse
import csv
import itertools
import json
import math
import re
import statistics
from pathlib import Path

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--allow-partial', action='store_true')
args = parser.parse_args()
root = Path(__file__).resolve().parent
seconds_by_case = {'idle': 15, 'rain': 45, 'meltdown': 46}
metrics = ['avg_step_ms', 'avg_render_ms', 'avg_present_ms', 'avg_total_ms']
sha256 = json.loads((root / 'builds.json').read_text())['client_sha256']


def means(rows):
    frames = sum(int(row['frames']) for row in rows)
    assert frames
    return {
        metric: sum(float(row[metric]) * int(row['frames']) for row in rows) / frames
        for metric in metrics
    }


def comparison(before, after):
    delta = [a - b for b, a in zip(before, after, strict=True)]
    baseline = statistics.median(before)
    return {
        'before_median': baseline,
        'after_median': statistics.median(after),
        'before_range': [min(before), max(before)],
        'after_range': [min(after), max(after)],
        'paired_delta_median': statistics.median(delta),
        'paired_delta_range': [min(delta), max(delta)],
        'percent_of_baseline': 100 * statistics.median(delta) / baseline if baseline else None,
    }


runs = []
for path in sorted((root / 'results').glob('*/*/*.csv')):
    match = re.fullmatch(
        r'(idle|rain|meltdown)-scale([12])-pair([123])-(before|after)',
        path.parent.parent.name,
    )
    assert match, path
    case, scale, pair, variant = match.groups()
    scale, pair = int(scale), int(pair)
    with path.open() as source:
        rows = list(csv.DictReader(source))
    seconds = seconds_by_case[case]
    if args.allow_partial and len(rows) != seconds:
        continue
    assert len(rows) == seconds, path
    assert [int(row['second']) for row in rows] == list(range(1, seconds + 1)), path
    for row in rows:
        assert int(row['frames']) == int(row['updates']) == 60, path
        assert row['benchmark_version'] == '2', path
        assert row['clock_case'] == case and row['seed'] == '7', path
        assert row['warmup_seconds'] == '5' and row['renderer'] == 'raster', path
        assert float(row['raster_scale']) == scale, path
        assert (int(row['viewport_width']), int(row['viewport_height'])) == (1024, 768), path
        assert (int(row['internal_width']), int(row['internal_height'])) == (1024 * scale, 768 * scale), path
        assert all(math.isfinite(float(row[key])) and float(row[key]) >= 0 for key in metrics), path
    assert sha256[variant] in (path.parent / 'metadata.txt').read_text(), path
    environment = []
    for env_path in sorted(path.parent.glob('*.environment-*.txt')):
        values = dict(line.split('=', 1) for line in env_path.read_text().splitlines() if '=' in line)
        environment.append({
            'file': env_path.name,
            'collected_utc': values['collected_utc'],
            'temperature_c': int(values['/sys/class/thermal/thermal_zone0/temp']) / 1000,
            'frequency_khz': int(values['/sys/devices/system/cpu/cpu0/cpufreq/scaling_cur_freq']),
            'governor': values['/sys/devices/system/cpu/cpu0/cpufreq/scaling_governor'],
        })
    assert len(environment) == 2, path
    phases = {}
    active_rows = [row for row in rows if int(row['event_active_frames']) == int(row['frames'])]
    if active_rows:
        phases['fully_active_rows'] = means(active_rows)
    if case == 'rain':
        phases['shower_seconds_1_20'] = means(rows[:20])
        phases['drain_seconds_21_40'] = means(rows[20:40])
    runs.append({
        'case': case, 'scale': scale, 'pair': pair, 'variant': variant,
        'frames': sum(int(row['frames']) for row in rows),
        'event_frames': sum(int(row['event_active_frames']) for row in rows),
        'max_scene_items': max(int(row['max_scene_items']) for row in rows),
        'max_bodies': max(int(row['max_bodies']) for row in rows),
        'max_colliders': max(int(row['max_colliders']) for row in rows),
        'worst_row_p95_ms': max(float(row['p95_total_ms']) for row in rows),
        **means(rows), 'phases': phases, 'environment': environment,
        'path': str(path.relative_to(root)),
    })

keys = [(run['case'], run['scale'], run['pair'], run['variant']) for run in runs]
assert len(keys) == len(set(keys)), 'Duplicate run'
if not args.allow_partial:
    expected = set(itertools.product(seconds_by_case, [1, 2], [1, 2, 3], ['before', 'after']))
    assert set(keys) == expected, f'Missing runs: {expected - set(keys)}'

summary = []
for case, scale in itertools.product(seconds_by_case, [1, 2]):
    group = [run for run in runs if (run['case'], run['scale']) == (case, scale)]
    pairs = [pair for pair in [1, 2, 3] if len([run for run in group if run['pair'] == pair]) == 2]
    if not pairs:
        continue
    before = [next(run for run in group if run['pair'] == pair and run['variant'] == 'before') for pair in pairs]
    after = [next(run for run in group if run['pair'] == pair and run['variant'] == 'after') for pair in pairs]
    for b, a in zip(before, after, strict=True):
        assert (b['frames'], b['event_frames']) == (a['frames'], a['event_frames'])
    phases = before[0]['phases']
    summary.append({
        'case': case, 'scale': scale, 'pairs': len(pairs),
        'metrics': {key: comparison([r[key] for r in before], [r[key] for r in after]) for key in metrics},
        'phases': {
            phase: {key: comparison([r['phases'][phase][key] for r in before], [r['phases'][phase][key] for r in after]) for key in metrics}
            for phase in phases
        },
    })

(root / 'analysis.json').write_text(json.dumps({'runs': runs, 'summary': summary}, indent=2) + '\n')
print(f'{len(runs)}/36 complete runs; {sum(run["frames"] for run in runs):,} measured frames')
for entry in summary:
    print(entry['case'], entry['scale'], f"pairs={entry['pairs']}")
    for name, metric in entry['metrics'].items():
        lo, hi = metric['paired_delta_range']
        print(f"  {name}: {metric['before_median']:.4f} -> {metric['after_median']:.4f} ms; "
              f"paired delta {metric['paired_delta_median']:+.4f} ({metric['percent_of_baseline']:+.1f}%); "
              f"delta range [{lo:+.4f}, {hi:+.4f}]")
if runs:
    environment = [reading for run in runs for reading in run['environment']]
    print('Temperature range C:', min(r['temperature_c'] for r in environment), max(r['temperature_c'] for r in environment))
    print('Frequency readings kHz:', sorted({r['frequency_khz'] for r in environment}))
