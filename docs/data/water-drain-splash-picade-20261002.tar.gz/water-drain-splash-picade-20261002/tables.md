| Fixture | Scale | Off (ms) | Lively (ms) | Paired change | Range of paired changes |
| --- | ---: | ---: | ---: | ---: | ---: |
| Idle | 1× | 6.371 | 6.336 | -0.034 ms (-0.5%) | -0.035 to -0.003 ms |
| Idle | 2× | 20.148 | 20.052 | -0.109 ms (-0.5%) | -0.132 to +0.059 ms |
| Heavy Rain | 1× | 7.961 | 7.943 | -0.020 ms (-0.2%) | -0.031 to -0.010 ms |
| Heavy Rain | 2× | 22.577 | 22.583 | +0.025 ms (+0.1%) | -0.091 to +0.185 ms |
| Meltdown | 1× | 5.653 | 5.669 | +0.015 ms (+0.3%) | -0.003 to +0.018 ms |
| Meltdown | 2× | 17.436 | 17.360 | -0.094 ms (-0.5%) | -0.175 to +0.005 ms |

| Fixture | Scale | Simulation off → Lively | Scene construction off → Lively | Raster preparation off → Lively |
| --- | ---: | ---: | ---: | ---: |
| Heavy Rain | 1× | 0.587 → 0.584 ms | 0.301 → 0.302 ms | 7.069 → 7.050 ms |
| Heavy Rain | 2× | 0.583 → 0.574 ms | 0.302 → 0.303 ms | 21.684 → 21.700 ms |
| Meltdown | 1× | 0.143 → 0.146 ms | 0.201 → 0.202 ms | 5.301 → 5.314 ms |
| Meltdown | 2× | 0.147 → 0.148 ms | 0.206 → 0.207 ms | 17.075 → 16.998 ms |

| Rain phase | Scale | Simulation off → Lively | Scene construction off → Lively | Total paired change |
| --- | ---: | ---: | ---: | ---: |
| Seconds 1–20 | 1× | 0.680 → 0.676 ms | 0.347 → 0.340 ms | -0.027 ms |
| Seconds 21–40 | 1× | 0.594 → 0.592 ms | 0.279 → 0.289 ms | -0.010 ms |
| Seconds 1–20 | 2× | 0.672 → 0.664 ms | 0.348 → 0.341 ms | +0.030 ms |
| Seconds 21–40 | 2× | 0.592 → 0.582 ms | 0.282 → 0.289 ms | +0.027 ms |
