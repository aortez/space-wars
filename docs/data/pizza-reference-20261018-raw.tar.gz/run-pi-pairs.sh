#!/bin/bash
set -euo pipefail
root=/tmp/spacewars-pizza-505-lazy-20261018
out="$root/results"
mkdir "$out"
was_active=$(systemctl is-active spacewars-kiosk.service || true)
cleanup() { if [[ "$was_active" == active ]]; then systemctl start spacewars-kiosk.service; fi; }
trap cleanup EXIT
trap 'exit 130' HUP INT TERM
systemctl stop spacewars-kiosk.service
uname -a > "$out/device.txt"
cat /proc/device-tree/model >> "$out/device.txt"
cat /sys/devices/system/cpu/cpu0/cpufreq/scaling_governor >> "$out/device.txt"
sha256sum "$root"/capacity-*-aarch64 > "$out/binaries.sha256"
for name in mixed-500 mixed-1000 mixed-2500 mixed-5000 ordinary-on; do
  n=${name#mixed-}
  steps=240; field=off; kind=mixed
  if [[ "$name" == ordinary-on ]]; then n=500; steps=1200; field=on; kind=ordinary; fi
  for r in 1 2 3; do
    order='baseline lazy'
    if [[ "$r" == 2 ]]; then order='lazy baseline'; fi
    for impl in $order; do
      stem="$name-$impl-$r"
      {
        echo before
        cat /proc/uptime /sys/class/thermal/thermal_zone0/temp /sys/devices/system/cpu/cpu0/cpufreq/scaling_cur_freq /sys/devices/platform/soc/soc:firmware/get_throttled
      } > "$out/$stem-device.txt"
      timeout 180 sudo -n -u spacewars -- "$root/capacity-$impl-aarch64" "$n" "$n" "$steps" 7 1024 768 "$field" "$kind" > "$out/$stem.json"
      {
        echo after
        cat /proc/uptime /sys/class/thermal/thermal_zone0/temp /sys/devices/system/cpu/cpu0/cpufreq/scaling_cur_freq /sys/devices/platform/soc/soc:firmware/get_throttled
      } >> "$out/$stem-device.txt"
      echo "$stem done"
    done
  done
 done
