| Fixture | Scale | Before (ms) | After (ms) | Paired increase | Range of paired increases |
| --- | ---: | ---: | ---: | ---: | ---: |
| Idle | 1× | 8.127 | 8.113 | -0.014 ms (-0.2%) | -0.016 to -0.006 ms |
| Idle | 2× | 27.230 | 27.283 | +0.036 ms (+0.1%) | +0.006 to +0.055 ms |
| Heavy Rain | 1× | 9.762 | 9.993 | +0.231 ms (+2.4%) | +0.228 to +0.238 ms |
| Heavy Rain | 2× | 29.680 | 30.096 | +0.425 ms (+1.4%) | +0.403 to +0.437 ms |
| Meltdown | 1× | 6.911 | 6.960 | +0.046 ms (+0.7%) | +0.033 to +0.063 ms |
| Meltdown | 2× | 22.190 | 22.423 | +0.225 ms (+1.0%) | +0.168 to +0.233 ms |

| Fixture | Scale | Simulation before → after | Scene construction before → after | Raster preparation before → after |
| --- | ---: | ---: | ---: | ---: |
| Heavy Rain | 1× | 0.477 → 0.574 ms | 0.270 → 0.300 ms | 9.010 → 9.111 ms |
| Heavy Rain | 2× | 0.472 → 0.575 ms | 0.271 → 0.302 ms | 28.929 → 29.215 ms |
| Meltdown | 1× | 0.117 → 0.140 ms | 0.182 → 0.203 ms | 6.606 → 6.609 ms |
| Meltdown | 2× | 0.120 → 0.143 ms | 0.186 → 0.208 ms | 21.877 → 22.066 ms |

| Rain phase | Scale | Simulation before → after | Scene construction before → after | Total paired increase |
| --- | ---: | ---: | ---: | ---: |
| Seconds 1–20 | 1× | 0.562 → 0.665 ms | 0.296 → 0.342 ms | +0.255 ms |
| Seconds 21–40 | 1× | 0.469 → 0.582 ms | 0.265 → 0.283 ms | +0.240 ms |
| Seconds 1–20 | 2× | 0.557 → 0.664 ms | 0.297 → 0.343 ms | +0.481 ms |
| Seconds 21–40 | 2× | 0.464 → 0.585 ms | 0.267 → 0.283 ms | +0.427 ms |
