Drain-wall collision profile, 2026-10-02

Final 36-run matrix only: Pi 4, seed 7, 1024x768, raster 1x/2x,
five warmup seconds, three pairs per case/scale, alternating build order.
Idle: 15 seconds; Heavy Rain: 45 seconds; Meltdown: 46 seconds.
The preliminary attempt with an actively rendering paused kiosk is excluded.

Analyze with Python 3.10 or newer (standard library only):
  python3 analyze.py
  python3 tables.py

The collector scripts are included. Rerunning run-paired.sh requires
before/engine-client and after/engine-client (not included); see builds.json.
Pause the kiosk first. The runner suspends its process, checks there is no
systemd watchdog, and resumes the process on exit. Manually resume the game
after collection. Benchmark time excludes final Slint/KMS display work.
