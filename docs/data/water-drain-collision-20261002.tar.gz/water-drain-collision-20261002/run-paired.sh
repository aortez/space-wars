#!/usr/bin/env bash
set -euo pipefail
profile_root=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
profile_kiosk_pid=$(systemctl show spacewars-kiosk.service -p MainPID --value)
[[ "$profile_kiosk_pid" =~ ^[1-9][0-9]*$ ]]
[[ $(systemctl show spacewars-kiosk.service -p User --value) == "$(id -un)" ]]
[[ $(systemctl show spacewars-kiosk.service -p WatchdogUSec --value) == 0 ]]
resume_kiosk() {
    kill -CONT "$profile_kiosk_pid" 2>/dev/null || true
}
trap resume_kiosk EXIT
trap 'exit 130' INT
trap 'exit 143' TERM
trap 'exit 129' HUP
kill -STOP "$profile_kiosk_pid"
for profile_wait in 1 2 3 4 5; do
    if grep -q '^State:.*T' "/proc/$profile_kiosk_pid/status"; then break; fi
    sleep 0.05
done
grep -q '^State:.*T' "/proc/$profile_kiosk_pid/status"
{
    date -u '+started_utc=%Y-%m-%dT%H:%M:%SZ'
    uname -a
    cat /proc/device-tree/model
    printf '\n'
    sha256sum "$profile_root/before/engine-client" "$profile_root/after/engine-client"
    printf 'seed=7 viewport=1024x768 scales=1,2 warmup=5 repeats=3\n'
    printf 'idle_seconds=15 rain_seconds=45 meltdown_seconds=46\n'
    printf 'order=before-after,after-before,before-after per workload/scale pair\n'
    printf 'kiosk=paused existing Spacewars session, SIGSTOP during benchmark; saved preferences unchanged\n'
    printf 'kiosk_pid=%s\n' "$profile_kiosk_pid"
    printf 'kiosk_stat_before='
    cat "/proc/$profile_kiosk_pid/stat"
} > "$profile_root/metadata.txt"
printf 'sequence,pair,case,scale,variant,seconds\n' > "$profile_root/order.csv"
profile_sequence=0
for profile_pair in 1 2 3; do
    for profile_case in idle rain meltdown; do
        case "$profile_case" in
            idle) profile_seconds=15 ;;
            rain) profile_seconds=45 ;;
            meltdown) profile_seconds=46 ;;
        esac
        for profile_scale in 1 2; do
            profile_variants=(before after)
            if (( profile_pair == 2 )); then profile_variants=(after before); fi
            for profile_variant in "${profile_variants[@]}"; do
                profile_sequence=$((profile_sequence + 1))
                printf '%s,%s,%s,%s,%s,%s\n' "$profile_sequence" "$profile_pair" "$profile_case" "$profile_scale" "$profile_variant" "$profile_seconds" >> "$profile_root/order.csv"
                printf '\n[%s/36] %s scale=%s pair=%s %s\n' "$profile_sequence" "$profile_case" "$profile_scale" "$profile_pair" "$profile_variant"
                timeout 240 bash "$profile_root/benchmark-clock.sh" \
                    --client "$profile_root/$profile_variant/engine-client" \
                    --output "$profile_root/results/$profile_case-scale$profile_scale-pair$profile_pair-$profile_variant" \
                    --renderer raster --scales "$profile_scale" --cases "$profile_case" \
                    --seed 7 --repeats 1 --seconds "$profile_seconds" --warmup 5 \
                    --width 1024 --height 768
            done
        done
    done
done
{
    date -u '+finished_utc=%Y-%m-%dT%H:%M:%SZ'
    printf 'kiosk_stat_after='
    cat "/proc/$profile_kiosk_pid/stat"
} >> "$profile_root/metadata.txt"
